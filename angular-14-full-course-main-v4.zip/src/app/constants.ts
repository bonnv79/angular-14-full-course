export const LOCAL_STORAGE_KEY_NAMES = {
  USER_INFO: 'userInfo',
  CART: 'cart',
}
