export interface PipeTransform {
  transform(value: any, ...args: any[]): any;
}