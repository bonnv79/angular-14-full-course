export interface Book {
  id: string;
  name: string;
  author: string;
  image: string;
  price: number;
}
