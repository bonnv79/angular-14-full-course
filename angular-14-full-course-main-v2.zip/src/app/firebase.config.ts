// Import the functions you need from the SDKs you need

// Your web app's Firebase configuration
export const firebaseConfig = {
  apiKey: "AIzaSyAlzUMTxoY6suw1XGKDwzkLzzk2rDDU6sk",
  authDomain: "angular-example-a3dc0.firebaseapp.com",
  projectId: "angular-example-a3dc0",
  storageBucket: "angular-example-a3dc0.appspot.com",
  messagingSenderId: "407789392272",
  appId: "1:407789392272:web:661dfd6cd7f9d4ca6ce315",
  measurementId: "G-SPFHX0V3WD"
};
